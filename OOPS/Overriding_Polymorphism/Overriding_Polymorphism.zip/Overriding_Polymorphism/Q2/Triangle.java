public class Triangle extends Shape {
	
	//@override
		public void draw() {
			System.out.println("Drawing triangle.");
		}
		
		//@override
		public void erase() {
			System.out.println("Erasing triangle");
		}


}
