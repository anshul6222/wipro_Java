public class Square  extends Shape{
	
	//@override
		public void draw() {
			System.out.println("Drawing square.");
		}
		
		//@override
		public void erase() {
			System.out.println("Erasing square");
		}


}