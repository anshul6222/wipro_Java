public class Shape {
	
	public void draw() {
		// Drawing Shape;
	}
	
	public void erase() {
		// Erasing shape;
	}

}