public class Circle  extends Shape{
	
	//@override
	public void draw() {
		System.out.println("Drawing circle.");
	}
	
	//@override
	public void erase() {
		System.out.println("Erasing circle");
	}

}
