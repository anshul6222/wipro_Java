public class DriverClass {
	public static void main(String[] args) {
		
		CollegeStudent obj1 = new CollegeStudent("Abhish Mathew", 23, 4, "Computer Science");
		obj1.show();
		Teacher obj2 = new Teacher("Sonam Joshi", 28, 20000, "Electrical Engineering");
		obj2.show();
	}
}