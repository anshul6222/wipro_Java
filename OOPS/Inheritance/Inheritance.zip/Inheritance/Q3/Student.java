public class Student {
	String student_name;
	int student_age;
	
	Student(String student_name, int student_age){
		this.student_age = student_age;
		this.student_name = student_name;
	}
}
