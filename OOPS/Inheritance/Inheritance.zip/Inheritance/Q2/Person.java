
public class Person {
	String name;
	
	Person(String name){
		this.name = name;
	}
}
