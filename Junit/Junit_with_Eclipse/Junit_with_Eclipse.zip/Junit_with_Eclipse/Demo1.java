package junit.first;

public class Demo1 {
	
	String stringConcat(String a, String b) {
		return a + b;
	}

}
