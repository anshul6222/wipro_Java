public class Luggage extends Compartment{
	
	public String notice() {
		
		return "This is a Luggage compartment.";
	}

}
