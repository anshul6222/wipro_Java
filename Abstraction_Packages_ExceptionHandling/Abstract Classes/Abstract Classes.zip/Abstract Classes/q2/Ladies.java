public class Ladies extends Compartment{
	
	public String notice() {
		
		return "This is a Ladies compartment.";
	}

}
