public class KotMBank extends GeneralBank {
	
	public double getFixedDepositInterestRate() {
		
		return 6;
	}
	
	public double getSavingsInterestRate() {
		
		return 9;
	}

}
