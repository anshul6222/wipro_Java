public class Piano extends Instrument {
	
	public void play() {
		System.out.println("Piano is playing  tan tan tan tan");
	}

}
