package test;
 class Foundation{

 	private int var1 = 1; 
 	int var2 = 2;
 	protected int var3 = 3;
 	public int var4 = 4;


 }