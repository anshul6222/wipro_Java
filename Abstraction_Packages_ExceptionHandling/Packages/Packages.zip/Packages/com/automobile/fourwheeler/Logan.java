package com.automobile.fourwheeler;
class Logan extends com.automobile.Vehicle{

	public String getModelName(){
		return "Logan" ;
	}

	public String getRegistrationNumber(){
		return "19822323";
	}

	public String getOwnerName(){
		return "Aakash Chopra";
	}

	public int speed(){
		return 146;
	}

	public int gps(){
		return -1;
	}
}