package com.automobile.fourwheeler;
class Ford extends com.automobile.Vehicle{

	public String getModelName(){
		return "Logan" ;
	}

	public String getRegistrationNumber(){
		return "19822323";
	}

	public String getOwnerName(){
		return "Aakash Chopra";
	}

	public int speed(){
		return 129;
	}

	public int tempControl(){
		return -999;
	}


}	