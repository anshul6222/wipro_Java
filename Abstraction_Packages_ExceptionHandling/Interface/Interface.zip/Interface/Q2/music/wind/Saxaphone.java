package music.wind;

public class Saxaphone implements music.Playable{

	public void play(){
		System.out.println("Saxaphone is playing");
	}

}