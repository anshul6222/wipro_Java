package music.string;
public class Veena implements music.Playable{

	public void play(){
		System.out.println("Veena is playing.");
	}
}
