package music.live;
import music.string.Veena;
import music.wind.Saxaphone;

class Test{
	public static void main(String[] args) {
		Veena obj1 = new Veena();
		obj1.play();

		Saxaphone obj2 = new Saxaphone();
		obj2.play();
	}
}